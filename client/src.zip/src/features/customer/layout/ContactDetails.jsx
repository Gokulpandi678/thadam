import { useState } from "react";
import useCustomer from "../../../hooks/useCustomer";
import ProfileCard from "../component/detail/ProfileCard";
import EditCustomerSidebar from "./EditCustomerSidebar";
import MeetingHistory from "../component/detail/MeetingHistory";
import AdditionalDetails from "../component/detail/AdditionalContactDetails";
import ConfirmationModal from "../../actions/ConfirmationModal";
import { useDeleteCustomer } from "../../../service/useCustomerApi";
import { getFullName } from "../../../utils/customer.utils";
import ConvertAsClientModal from "../../client/ConvertAsClientModal";

const ContactDetails = ({ customer: initialCustomer, onDeleteSuccess }) => {
    const {
        customer, profileCompletion,
        handleEdit, handleLogMeeting,
        isEditing, cancelEdit,
    } = useCustomer(initialCustomer);

    const [customerToDelete, setCustomerToDelete] = useState(null);
    const [showConvertModal, setShowConvertModal] = useState(false); // ← NEW

    const { mutate: deleteCustomer, isPending: isDeleting } = useDeleteCustomer();

    const handleDeleteConfirm = () => {
        deleteCustomer(customerToDelete?.id, {
            onSuccess: () => {
                setCustomerToDelete(null);
                onDeleteSuccess?.();
            },
        });
    };

    if (!customer) return null;

    return (
        <>
            <div
                className="grid gap-5 p-6 h-[87vh] overflow-hidden"
                style={{ gridTemplateColumns: "300px 1fr" }}
            >
                <div className="overflow-hidden">
                    <ProfileCard
                        customer={customer}
                        profileCompletion={profileCompletion}
                        onEdit={handleEdit}
                        onConvertAsClient={() => setShowConvertModal(true)}
                        onDelete={() => setCustomerToDelete(customer)}
                    />
                </div>

                <div className="flex flex-col gap-4 overflow-y-auto pr-1">
                    <AdditionalDetails customer={customer} />
                    <MeetingHistory customer={customer} onLogMeeting={handleLogMeeting} />
                </div>

                {isEditing && (
                    <EditCustomerSidebar
                        customer={customer}
                        onClose={cancelEdit}
                        isOpen={isEditing}
                    />
                )}
            </div>

            {/* Convert as Client modal */}
            <ConvertAsClientModal
                isOpen={showConvertModal}
                onClose={() => setShowConvertModal(false)}
                customer={customer}
            />

            <ConfirmationModal
                isOpen={!!customerToDelete}
                title="Delete customer"
                message={`"${getFullName(customerToDelete)}" will be moved to the temporary delete bin and permanently deleted after 30 days.`}
                confirmLabel="Delete"
                onConfirm={handleDeleteConfirm}
                onCancel={() => setCustomerToDelete(null)}
                isLoading={isDeleting}
                variant="danger"
            />
        </>
    );
};

export default ContactDetails;