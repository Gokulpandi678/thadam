import { useState, useEffect } from "react";
import { X, Save } from "lucide-react";
import { useUpdateClient } from "../../service/useClientApi";

const CLIENT_TYPES = [
    "Freelance client", "Business partner", "Employer", "Referral partner", "Retainer client",
];
const ENGAGEMENT_TYPES = ["One-time", "Ongoing", "Contract-based", "As needed"];
const VALUE_TAGS = [
    "Jobs / work", "Freelance projects", "Reputation / brand",
    "Partnership", "Referrals", "Networking", "Mentorship", "Collaboration",
];

const EditClientModal = ({ isOpen, onClose, client }) => {
    const [form, setForm] = useState(null);
    const { mutate: update, isPending } = useUpdateClient();

    useEffect(() => {
        if (isOpen && client) {
            setForm({
                clientType:       client.clientType       ?? "Freelance client",
                clientSince:      client.clientSince      ?? new Date().toISOString().split("T")[0],
                conversionReason: client.conversionReason ?? "",
                // valueTags is already List<String> from backend
                valueTags:        Array.isArray(client.valueTags) ? client.valueTags : [],
                engagementType:   client.engagementType   ?? "Ongoing",
                nextFollowUp:     client.nextFollowUp     ?? "",
                notes:            client.notes            ?? "",
            });
        }
    }, [isOpen, client]);

    useEffect(() => {
        const handler = (e) => { if (e.key === "Escape") onClose(); };
        if (isOpen) document.addEventListener("keydown", handler);
        return () => document.removeEventListener("keydown", handler);
    }, [isOpen, onClose]);

    if (!isOpen || !client || !form) return null;

    const toggleTag = (tag) =>
        setForm(prev => ({
            ...prev,
            valueTags: prev.valueTags.includes(tag)
                ? prev.valueTags.filter(t => t !== tag)
                : [...prev.valueTags, tag],
        }));

    const handleSubmit = () => {
        update(
            {
                customerId: client.customerId,
                params: {
                    ...form,
                    valueTags: form.valueTags.join(","),
                    clientSince:      form.clientSince      || null,
                    nextFollowUp:     form.nextFollowUp     || null,
                    conversionReason: form.conversionReason || null,
                    notes:            form.notes            || null,
                },
            },
            { onSuccess: () => onClose() }
        );
    };

    // ClientResponse has flat firstName/lastName (not customerFirstName)
    const initials = `${client.firstName?.[0] ?? ""}${client.lastName?.[0] ?? ""}`.toUpperCase();
    const fullName  = `${client.firstName ?? ""} ${client.lastName ?? ""}`.trim();

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-[520px] mx-4 overflow-hidden" onClick={e => e.stopPropagation()}>

                {/* Header */}
                <div className="bg-blue-600 px-6 py-5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white text-sm font-semibold shrink-0">
                            {initials}
                        </div>
                        <div>
                            <p className="text-white text-[15px] font-semibold leading-tight">Edit client — {fullName}</p>
                            <p className="text-blue-200 text-[12px]">{client.designation} · {client.company}</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="w-7 h-7 rounded-full bg-white/15 flex items-center justify-center text-white hover:bg-white/25 transition-colors cursor-pointer">
                        <X size={15} />
                    </button>
                </div>

                {/* Body */}
                <div className="px-6 py-5 flex flex-col gap-5 max-h-[70vh] overflow-y-auto">

                    <div>
                        <p className="text-[10px] uppercase tracking-widest text-slate-400 font-medium mb-3">Relationship details</p>
                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className="text-[11px] text-slate-500 block mb-1">Client type</label>
                                <select value={form.clientType} onChange={e => setForm(p => ({ ...p, clientType: e.target.value }))}
                                    className="w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400">
                                    {CLIENT_TYPES.map(t => <option key={t}>{t}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[11px] text-slate-500 block mb-1">Client since</label>
                                <input type="date" value={form.clientSince} onChange={e => setForm(p => ({ ...p, clientSince: e.target.value }))}
                                    className="w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400" />
                            </div>
                            <div className="col-span-2">
                                <label className="text-[11px] text-slate-500 block mb-1">How did they become a client?</label>
                                <input type="text" placeholder="e.g. Offered a freelance web project" value={form.conversionReason}
                                    onChange={e => setForm(p => ({ ...p, conversionReason: e.target.value }))}
                                    className="w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400" />
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-slate-100 pt-4">
                        <p className="text-[10px] uppercase tracking-widest text-slate-400 font-medium mb-3">What do they bring?</p>
                        <div className="flex flex-wrap gap-2">
                            {VALUE_TAGS.map(tag => (
                                <button key={tag} type="button" onClick={() => toggleTag(tag)}
                                    className={`text-[12px] px-3 py-1.5 rounded-full border transition-all cursor-pointer ${form.valueTags.includes(tag) ? "bg-blue-600 text-white border-blue-600" : "bg-white text-slate-600 border-slate-200 hover:border-blue-300 hover:text-blue-600"}`}>
                                    {tag}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="border-t border-slate-100 pt-4">
                        <p className="text-[10px] uppercase tracking-widest text-slate-400 font-medium mb-3">Engagement</p>
                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className="text-[11px] text-slate-500 block mb-1">Engagement type</label>
                                <select value={form.engagementType} onChange={e => setForm(p => ({ ...p, engagementType: e.target.value }))}
                                    className="w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400">
                                    {ENGAGEMENT_TYPES.map(t => <option key={t}>{t}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[11px] text-slate-500 block mb-1">Next follow-up</label>
                                <input type="date" value={form.nextFollowUp} onChange={e => setForm(p => ({ ...p, nextFollowUp: e.target.value }))}
                                    className="w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400" />
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-slate-100 pt-4">
                        <p className="text-[10px] uppercase tracking-widest text-slate-400 font-medium mb-3">Notes</p>
                        <textarea rows={2} placeholder="Any context, terms, or notes..." value={form.notes}
                            onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}
                            className="w-full text-[13px] border border-slate-200 rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400" />
                    </div>
                </div>

                {/* Footer */}
                <div className="px-6 py-4 border-t border-slate-100 flex gap-2">
                    <button onClick={handleSubmit} disabled={isPending}
                        className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white text-[13px] font-medium py-2.5 rounded-xl hover:bg-blue-700 transition-colors cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed">
                        <Save size={15} />
                        {isPending ? "Saving..." : "Save changes"}
                    </button>
                    <button onClick={onClose} disabled={isPending}
                        className="px-5 py-2.5 text-[13px] text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    );
};

export default EditClientModal;