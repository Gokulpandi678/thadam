package mapper;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import entity.ClientEntity;
import entity.CustomerEntity;
import request.ClientRequest;
import response.ClientResponse;
import response.CustomerLogResponse;

public final class ClientMapper {

    private ClientMapper() {
        // utility class
    }

    public static ClientEntity toEntity(ClientRequest req, String ownerId, java.util.UUID customerId) {
        return ClientEntity.builder()
                .customerId(customerId)
                .ownerId(ownerId)
                .clientType(nullIfEmpty(req.getClientType()))
                .clientSince(req.getClientSince() != null ? req.getClientSince() : LocalDate.now())
                .conversionReason(nullIfEmpty(req.getConversionReason()))
                .valueTags(nullIfEmpty(req.getValueTags()))
                .engagementType(nullIfEmpty(req.getEngagementType()))
                .nextFollowUp(req.getNextFollowUp())
                .notes(nullIfEmpty(req.getNotes()))
                .build();
    }

    /**
     * Used in list responses — no logs included.
     */
    public static ClientResponse toResponse(ClientEntity client, CustomerEntity customer) {
        return toResponse(client, customer, Collections.emptyList());
    }

    /**
     * Used in single fetch — logs included.
     */
    public static ClientResponse toResponse(ClientEntity client, CustomerEntity customer,
            List<CustomerLogResponse> logs) {
        return ClientResponse.builder()
                .id(client.getId())
                .customerId(client.getCustomerId())
                // Relationship
                .clientType(client.getClientType())
                .clientSince(client.getClientSince())
                .conversionReason(client.getConversionReason())
                .valueTags(splitTags(client.getValueTags()))
                // Engagement
                .engagementType(client.getEngagementType())
                .nextFollowUp(client.getNextFollowUp())
                // Notes
                .notes(client.getNotes())
                // Customer snapshot — so frontend doesn't need a second call
                .customerFirstName(customer.getFirstName())
                .customerLastName(customer.getLastName())
                .customerRole(customer.getRole())
                .customerDesignation(customer.getDesignation())
                .customerCompany(customer.getCompany())
                .customerProfilePicture(customer.getProfilePicture())
                // Logs
                .logs(logs)
                // Timestamps
                .createdAt(client.getCreatedAt())
                .updatedAt(client.getUpdatedAt())
                .build();
    }

    // ── Helpers ───────────────────────────────────────────────

    private static List<String> splitTags(String valueTags) {
        if (valueTags == null || valueTags.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.stream(valueTags.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    private static String nullIfEmpty(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }
        return value.trim();
    }
}