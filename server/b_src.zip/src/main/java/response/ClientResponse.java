package response;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ClientResponse {

    private UUID id;
    private UUID customerId;

    // ── Relationship Details ───────────────────────────────────
    private String clientType;
    private LocalDate clientSince;
    private String conversionReason;
    private List<String> valueTags;      // returned as a list (split from comma-separated)

    // ── Engagement ────────────────────────────────────────────
    private String engagementType;
    private LocalDate nextFollowUp;

    // ── Notes ─────────────────────────────────────────────────
    private String notes;

    // ── Snapshot of the customer at response time ──────────────
    // Avoids the frontend making a second API call just to show name/company
    private String customerFirstName;
    private String customerLastName;
    private String customerRole;
    private String customerDesignation;
    private String customerCompany;
    private String customerProfilePicture;

    // ── Logs linked to this customer ──────────────────────────
    // Included only in getClient (single fetch), empty in list responses
    private List<CustomerLogResponse> logs;

    // ── Timestamps ────────────────────────────────────────────
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}