package controller;

import java.util.UUID;

import org.jboss.resteasy.reactive.RestResponse;

import context.RequestContext;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.RequiredArgsConstructor;
import request.ClientRequest;
import response.GenericResponse;
import service.ClientService;

@Path("/api/v1/clients")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RequiredArgsConstructor
public class ClientController {

	private final ClientService clientService;
	private final RequestContext requestContext;

	/**
	 * POST /api/v1/clients/{customerId}/convert Converts a contact into a client.
	 */
	@POST
	@Path("/{customerId}/convert")
	public RestResponse<GenericResponse> convertAsClient(@PathParam("customerId") UUID customerId,
			@Valid ClientRequest request) {
		return clientService.convertAsClient(customerId, request, requestContext.getUserId());
	}

	/**
	 * GET /api/v1/clients/{customerId} Fetches the full client profile including
	 * logs (for timeline).
	 */
	@GET
	@Path("/{customerId}")
	public RestResponse<GenericResponse> getClient(@PathParam("customerId") UUID customerId) {
		return clientService.getClient(customerId, requestContext.getUserId());
	}

	/**
	 * PUT /api/v1/clients/{customerId} Updates the client profile details.
	 */
	@PUT
	@Path("/{customerId}")
	public RestResponse<GenericResponse> updateClient(@PathParam("customerId") UUID customerId,
			@Valid ClientRequest request) {
		return clientService.updateClient(customerId, request, requestContext.getUserId());
	}

	/**
	 * DELETE /api/v1/clients/{customerId}/revert Reverts a client back to a regular
	 * contact.
	 */
	@DELETE
	@Path("/{customerId}/revert")
	public RestResponse<GenericResponse> revertClient(@PathParam("customerId") UUID customerId) {
		return clientService.revertClient(customerId, requestContext.getUserId());
	}
}