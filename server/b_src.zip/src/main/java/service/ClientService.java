package service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.jboss.resteasy.reactive.RestResponse;

import entity.ClientEntity;
import entity.CustomerEntity;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import mapper.ClientMapper;
import mapper.CustomerLogMapper;
import repositories.ClientRepository;
import repositories.CustomerLogRepository;
import repositories.CustomerRepository;
import request.ClientRequest;
import response.CustomerLogResponse;
import response.GenericResponse;
import response.PrepareResponse;

@ApplicationScoped
public class ClientService {

    @Inject
    ClientRepository clientRepository;

    @Inject
    CustomerRepository customerRepository;

    @Inject
    CustomerLogRepository customerLogRepository;

    @Inject
    PrepareResponse prepareResponse;

    /**
     * Converts a contact into a client.
     * - Validates the customer exists and belongs to the owner
     * - Prevents double-conversion (one client record per customer)
     * - Updates the customer's role to "Client" to reflect in the contacts list
     * - Creates the client record linked by customer_id
     */
    @Transactional
    public RestResponse<GenericResponse> convertAsClient(UUID customerId, ClientRequest request, String ownerId) {
        Log.debugf("Converting customer id=%s to client for ownerId=%s", customerId, ownerId);
        try {
            // 1. Verify the customer exists and belongs to this owner
            CustomerEntity customer = customerRepository.findByIdAndOwner(customerId, ownerId).orElse(null);
            if (customer == null) {
                Log.warnf("Customer id=%s not found or does not belong to ownerId=%s on convertAsClient", customerId,
                        ownerId);
                return prepareResponse.badRequest("Customer not found");
            }

            // 2. Prevent converting the same customer twice
            if (clientRepository.existsByCustomerId(customerId)) {
                Log.warnf("Customer id=%s is already a client for ownerId=%s", customerId, ownerId);
                return prepareResponse.conflict("This contact is already a client");
            }

            // 3. Create the client record
            ClientEntity client = ClientMapper.toEntity(request, ownerId, customerId);
            clientRepository.persist(client);
            Log.infof("Client record created with id=%s for customer id=%s", client.getId(), customerId);

            // 4. Update the customer's role to "Client" — reflects in contacts list
            customer.setRole("Client");
            customerRepository.persist(customer);
            Log.infof("Customer id=%s role updated to 'Client' for ownerId=%s", customerId, ownerId);

            return prepareResponse.successMessageWithObject("Contact successfully converted to client",
                    ClientMapper.toResponse(client, customer));

        } catch (Exception e) {
            Log.errorf("Failed to convert customer %s to client for ownerId %s: %s", customerId, ownerId,
                    e.getMessage());
            return prepareResponse.failureMessage("Failed to convert contact to client");
        }
    }

    /**
     * Fetches the client profile for a given customer.
     * Includes the customer's meeting logs for timeline support.
     */
    public RestResponse<GenericResponse> getClient(UUID customerId, String ownerId) {
        Log.debugf("Fetching client profile for customer id=%s, ownerId=%s", customerId, ownerId);
        try {
            CustomerEntity customer = customerRepository.findByIdAndOwner(customerId, ownerId).orElse(null);
            if (customer == null) {
                Log.warnf("Customer id=%s not found or does not belong to ownerId=%s on getClient", customerId,
                        ownerId);
                return prepareResponse.badRequest("Customer not found");
            }

            ClientEntity client = clientRepository.findByCustomerIdAndOwner(customerId, ownerId).orElse(null);
            if (client == null) {
                Log.warnf("No client record found for customer id=%s, ownerId=%s", customerId, ownerId);
                return prepareResponse.badRequest("This contact has not been converted to a client yet");
            }

            // Include logs — foundation for the future customer journey timeline
            List<CustomerLogResponse> logs = customerLogRepository.findAllByCustomer(customerId).stream()
                    .map(CustomerLogMapper::toResponse)
                    .collect(Collectors.toList());

            Log.infof("Client profile fetched for customer id=%s with %d log(s)", customerId, logs.size());

            return prepareResponse.successMessageWithObject("Client fetched successfully",
                    ClientMapper.toResponse(client, customer, logs));

        } catch (Exception e) {
            Log.errorf("Failed to fetch client for customer %s, ownerId %s: %s", customerId, ownerId, e.getMessage());
            return prepareResponse.failureMessage("Failed to fetch client");
        }
    }

    /**
     * Updates the client profile details (type, tags, notes, follow-up etc.)
     * Does NOT touch the customer record — only the clients table.
     */
    @Transactional
    public RestResponse<GenericResponse> updateClient(UUID customerId, ClientRequest request, String ownerId) {
        Log.debugf("Updating client for customer id=%s, ownerId=%s", customerId, ownerId);
        try {
            CustomerEntity customer = customerRepository.findByIdAndOwner(customerId, ownerId).orElse(null);
            if (customer == null) {
                Log.warnf("Customer id=%s not found or does not belong to ownerId=%s on updateClient", customerId,
                        ownerId);
                return prepareResponse.badRequest("Customer not found");
            }

            ClientEntity client = clientRepository.findByCustomerIdAndOwner(customerId, ownerId).orElse(null);
            if (client == null) {
                Log.warnf("No client record found for customer id=%s on update", customerId);
                return prepareResponse.badRequest("Client record not found");
            }

            // Update client fields
            client.setClientType(request.getClientType());
            client.setClientSince(request.getClientSince());
            client.setConversionReason(request.getConversionReason());
            client.setValueTags(request.getValueTags());
            client.setEngagementType(request.getEngagementType());
            client.setNextFollowUp(request.getNextFollowUp());
            client.setNotes(request.getNotes());

            clientRepository.persist(client);
            Log.infof("Client record updated for customer id=%s by ownerId=%s", customerId, ownerId);

            return prepareResponse.successMessageWithObject("Client updated successfully",
                    ClientMapper.toResponse(client, customer));

        } catch (Exception e) {
            Log.errorf("Failed to update client for customer %s, ownerId %s: %s", customerId, ownerId, e.getMessage());
            return prepareResponse.failureMessage("Failed to update client");
        }
    }

    /**
     * Reverts a client back to a regular contact.
     * - Deletes the client record
     * - Resets the customer's role back to "Lead"
     */
    @Transactional
    public RestResponse<GenericResponse> revertClient(UUID customerId, String ownerId) {
        Log.debugf("Reverting client for customer id=%s, ownerId=%s", customerId, ownerId);
        try {
            CustomerEntity customer = customerRepository.findByIdAndOwner(customerId, ownerId).orElse(null);
            if (customer == null) {
                Log.warnf("Customer id=%s not found or does not belong to ownerId=%s on revertClient", customerId,
                        ownerId);
                return prepareResponse.badRequest("Customer not found");
            }

            ClientEntity client = clientRepository.findByCustomerIdAndOwner(customerId, ownerId).orElse(null);
            if (client == null) {
                Log.warnf("No client record found for customer id=%s on revert", customerId);
                return prepareResponse.badRequest("Client record not found");
            }

            // Remove client record
            clientRepository.delete(client);
            Log.infof("Client record deleted for customer id=%s", customerId);

            // Reset role back to Lead
            customer.setRole("Lead");
            customerRepository.persist(customer);
            Log.infof("Customer id=%s role reverted to 'Lead' for ownerId=%s", customerId, ownerId);

            return prepareResponse.successMessage("Client reverted to contact successfully");

        } catch (Exception e) {
            Log.errorf("Failed to revert client for customer %s, ownerId %s: %s", customerId, ownerId, e.getMessage());
            return prepareResponse.failureMessage("Failed to revert client");
        }
    }
}