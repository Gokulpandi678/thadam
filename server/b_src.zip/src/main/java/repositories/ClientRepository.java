package repositories;

import java.util.Optional;
import java.util.UUID;

import entity.ClientEntity;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ClientRepository implements PanacheRepositoryBase<ClientEntity, UUID> {

    public Optional<ClientEntity> findByCustomerId(UUID customerId) {
        return find("customerId = ?1", customerId).firstResultOptional();
    }

    public Optional<ClientEntity> findByCustomerIdAndOwner(UUID customerId, String ownerId) {
        return find("customerId = ?1 and ownerId = ?2", customerId, ownerId).firstResultOptional();
    }

    public boolean existsByCustomerId(UUID customerId) {
        return count("customerId = ?1", customerId) > 0;
    }
}